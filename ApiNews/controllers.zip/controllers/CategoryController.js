const { Category } = require('../models/CategoryModel');
const { validationResult } = require('express-validator');

const get = (request, response) => {
  const filters = request.query;
  Category.findAll({ where: filters })
    .then(entities => {
      response.json(entities);
    })
    .catch(err => {
      console.error("Error al consultar categorías:", err);
      response.status(500).send('Error consultando los datos');
    });
};

const getById = (request, response) => {
  const id = request.params.id;
  Category.findByPk(id)
    .then(entitie => {
      if (entitie) {
        response.json(entitie);
      } else {
        response.status(404).send('Recurso no encontrado');
      }
    })
    .catch(err => {
      console.error("Error al consultar categoría por ID:", err);
      response.status(500).send('Error al consultar el dato');
    });
};

const create = (request, response) => {
  const errors = validationResult(request);
  if (!errors.isEmpty()) {
    return response.status(422).json({ errors: errors.mapped() });
  }
  const data = { ...request.body, FechaAlta: new Date(), FechaMod: new Date(), FechaBaja: '1990-01-01' };
  Category.create(data)
    .then(newEntitie => {
      response.status(201).json(newEntitie);
    })
    .catch(err => {
      console.error("Error al crear categoría:", err);
      response.status(500).send('Error al crear');
    });
};

const update = (request, response) => {
  const errors = validationResult(request);
  if (!errors.isEmpty()) {
    return response.status(422).json({ errors: errors.mapped() });
  }
  const id = request.params.id;
  Category.update(request.body, { where: { id: id } })
    .then(numRowsUpdatedArray => {
      const numRowsUpdated = numRowsUpdatedArray[0];
      if (numRowsUpdated > 0) {
        response.status(200).send(`${numRowsUpdated} registro actualizado`);
      } else {
        response.status(404).send('No se encontró el registro para actualizar');
      }
    })
    .catch(err => {
      console.error("Error al actualizar categoría:", err);
      response.status(500).send('Error al actualizar');
    });
};

const destroy = (request, response) => {
  const id = request.params.id;
  Category.destroy({ where: { id: id } })
    .then(numRowsDeleted => {
      if (numRowsDeleted > 0) {
        response.status(200).send(`${numRowsDeleted} registro eliminado`);
      } else {
        response.status(404).send('No se encontró el registro para eliminar');
      }
    })
    .catch(err => {
      console.error("Error al eliminar categoría:", err);
      response.status(500).send('Error al eliminar');
    });
};

module.exports = { get, getById, create, update, destroy };