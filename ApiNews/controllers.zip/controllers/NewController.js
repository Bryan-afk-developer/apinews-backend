const { New } = require('../models/NewModel');
const { Category } = require('../models/CategoryModel');
const { State } = require('../models/StateModel');
const { User } = require('../models/UserModel');
const { Profile } = require('../models/ProfileModel');
const { validationResult } = require('express-validator');

const relationsUser = [
    { model: Profile, attributes: ['id', 'nombre'], as: 'perfil' }
];
const relations = [
    { model: Category, attributes: ['id', 'nombre', 'descripcion'], as: 'categoria' },
    { model: State, attributes: ['id', 'nombre', 'abreviacion'], as: 'estado' },
    { model: User, attributes: ['id', 'perfil_id', 'nick', 'nombre'], as: 'usuario', include: relationsUser }
];

const get = (request, response) => {
    const filters = request.query;
    New.findAll({ where: filters, include: relations })
        .then(entities => {
            response.json(entities);
        })
        .catch(err => {
            console.error("Error al consultar noticias:", err);
            response.status(500).send('Error consultando los datos');
        });
};

const getById = (request, response) => {
    const id = request.params.id;
    New.findByPk(id, { include: relations })
        .then(entitie => {
            if (entitie) {
                response.json(entitie);
            } else {
                response.status(404).send('Recurso no encontrado');
            }
        })
        .catch(err => {
            console.error("Error al consultar noticia por ID:", err);
            response.status(500).send('Error al consultar el dato');
        });
};

const create = (request, response) => {
    const errors = validationResult(request);
    if (!errors.isEmpty()) {
        return response.status(422).json({ errors: errors.mapped() });
    }
    const data = { ...request.body, FechaAlta: new Date(), FechaMod: new Date(), FechaBaja: '1990-01-01' };
    New.create(data)
        .then(newEntitie => {
            response.status(201).json(newEntitie);
        })
        .catch(err => {
            console.error("Error al crear noticia:", err);
            response.status(500).send('Error al crear');
        });
};

const update = (request, response) => {
    const errors = validationResult(request);
    if (!errors.isEmpty()) {
        return response.status(422).json({ errors: errors.mapped() });
    }
    const id = request.params.id;
    New.update(request.body, { where: { id: id } })
        .then(numRowsUpdatedArray => {
            const numRowsUpdated = numRowsUpdatedArray[0];
            if (numRowsUpdated > 0) {
                response.status(200).send(`${numRowsUpdated} registro actualizado`);
            } else {
                response.status(404).send('No se encontró el registro para actualizar');
            }
        })
        .catch(err => {
            console.error("Error al actualizar noticia:", err);
            response.status(500).send('Error al actualizar');
        });
};

const destroy = (request, response) => {
    const id = request.params.id;
    New.destroy({ where: { id: id } })
        .then(numRowsDeleted => {
            if (numRowsDeleted > 0) {
                response.status(200).send(`${numRowsDeleted} registro eliminado`);
            } else {
                response.status(404).send('No se encontró el registro para eliminar');
            }
        })
        .catch(err => {
            console.error("Error al eliminar noticia:", err);
            response.status(500).send('Error al eliminar');
        });
};

module.exports = { get, getById, create, update, destroy };