const { State } = require('../models/StateModel');
const { validationResult } = require('express-validator');

const create = (request, response) => {
    // 1. Validar la entrada
    const errors = validationResult(request);
    if (!errors.isEmpty()) {
        return response.status(422).json({ errors: errors.mapped() });
    }

    // 2. Construir el objeto de datos para la creación
    const data = {
        nombre: request.body.nombre,
        abreviacion: request.body.abreviacion,
        UserAlta: "Admin", // Asumimos un usuario por defecto
        FechaAlta: new Date(),
        // No incluimos los otros campos para que usen su valor por defecto (NULL)
    };

    // 3. Crear el registro en la base de datos
    State.create(data)
        .then(newEntitie => {
            response.status(201).json(newEntitie);
        })
        .catch(err => {
            console.error("ERROR DETALLADO AL CREAR ESTADO:", err);
            response.status(500).send('Error al crear el estado. Revisa la consola del servidor para más detalles.');
        });
};

// --- MANTÉN TUS OTRAS FUNCIONES (get, getById, update, destroy) COMO ESTABAN ---
// Asegúrate de que todas tengan el console.error en sus bloques .catch()

const get = (request, response) => {
  const filters = request.query;
  State.findAll({ where: filters })
    .then(entities => response.json(entities))
    .catch(err => {
      console.error("Error al consultar estados:", err);
      response.status(500).send('Error consultando los datos');
    });
};

const getById = (request, response) => {
  const id = request.params.id;
  State.findByPk(id)
    .then(entitie => {
      if (entitie) response.json(entitie);
      else response.status(404).send('Recurso no encontrado');
    })
    .catch(err => {
      console.error("Error al consultar estado por ID:", err);
      response.status(500).send('Error al consultar el dato');
    });
};

const update = (request, response) => {
  const errors = validationResult(request);
  if (!errors.isEmpty()) {
    return response.status(422).json({ errors: errors.mapped() });
  }
  const id = request.params.id;
  const dataToUpdate = { ...request.body, FechaMod: new Date(), UserMod: "Admin" }; // Añade auditoría de modificación
  State.update(dataToUpdate, { where: { id } })
    .then(numRowsUpdatedArray => {
      if (numRowsUpdatedArray[0] > 0) {
        response.status(200).send(`${numRowsUpdatedArray[0]} registro actualizado`);
      } else {
        response.status(404).send('No se encontró el registro para actualizar');
      }
    })
    .catch(err => {
      console.error("Error al actualizar estado:", err);
      response.status(500).send('Error al actualizar');
    });
};

const destroy = (request, response) => {
  const id = request.params.id;
  State.destroy({ where: { id } })
    .then(numRowsDeleted => {
      if (numRowsDeleted > 0) {
        response.status(200).send(`${numRowsDeleted} registro eliminado`);
      } else {
        response.status(404).send('No se encontró el registro para eliminar');
      }
    })
    .catch(err => {
      console.error("Error al eliminar estado:", err);
      response.status(500).send('Error al eliminar');
    });
};


module.exports = { get, getById, create, update, destroy };