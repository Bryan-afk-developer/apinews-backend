const { DataTypes } = require('sequelize');
const { connection } = require("../config.db");

const Profile = connection.define('profile', {
    nombre: {
        type: DataTypes.STRING,
        allowNull: false
    }
});

// Sincronizar el modelo con la base de datos
//Profile.sync();

module.exports = { Profile };