const { DataTypes } = require('sequelize');
const { connection } = require("../config.db");

const Category = connection.define('category', {
    nombre: {
        type: DataTypes.STRING(50),
        allowNull: false,
        unique: true
    },
    descripcion: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
    activo: {
        type: DataTypes.BOOLEAN,
        defaultValue: true,
        allowNull: false
    },
    UserAlta: {
        type: DataTypes.STRING(20),
        allowNull: false
    },
    FechaAlta: {
        type: DataTypes.DATE,
        allowNull: false
    },
    UserMod: {
        type: DataTypes.STRING(20),
        allowNull: false
    },
    FechaMod: {
        type: DataTypes.DATE,
        allowNull: false
    },
    UserBaja: {
        type: DataTypes.STRING(20),
        allowNull: false
    },
    FechaBaja: {
        type: DataTypes.DATE,
        allowNull: false
    }
});

//Category.sync();

module.exports = { Category };