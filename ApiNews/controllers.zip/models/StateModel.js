const { DataTypes } = require('sequelize');
const { connection } = require("../config.db");

const State = connection.define('state', {
    nombre: {
        type: DataTypes.STRING(50),
        allowNull: false,
        unique: true,
    },
    abreviacion: {
        type: DataTypes.STRING(5),
        allowNull: false,
        unique: true,
    },
    activo: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
    },
    UserAlta: {
        type: DataTypes.STRING(30),
        allowNull: false,
    },
    FechaAlta: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    UserMod: {
        type: DataTypes.STRING(30),
        allowNull: true, // Permitir nulos para campos que no se usan al crear
    },
    FechaMod: {
        type: DataTypes.DATE,
        allowNull: true, // Permitir nulos
    },
    UserBaja: {
        type: DataTypes.STRING(30),
        allowNull: true, // Permitir nulos
    },
    FechaBaja: {
        type: DataTypes.DATE,
        allowNull: true, // Permitir nulos
    },
});

// ¡Ya no necesitamos sync() aquí, app.js lo maneja!

module.exports = { State };